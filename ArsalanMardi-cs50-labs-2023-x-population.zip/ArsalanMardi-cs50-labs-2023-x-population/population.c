#include <cs50.h>
#include <stdio.h>

// allow program to use functions like get_int & printf
int main(void)
// Defines the program's main function, which is always the first function to be executed when the program is executed.
{
    // TODO: Prompt for start size
    int start, end, years = 0;

    do
    {
        start = get_int("tell me starting size: \n");
    }
    while (start < 9);
    // If the number entered is less than 9, the program forces the user to re-enter a number
    //  TODO: Prompt for end size
    do
    {
        end = get_int("tell me ending size size: \n ");
    }
    while (start > end);
    // If the entered number is less than or equal to the starting number, the program forces the user to re-enter a number
    // TODO: Calculate number of years until we reach threshold
    while (start < end)
    {
        start = (start + start / 3 - start / 4);
        years++;
    }
    // Three integer variables are defined

    // TODO: Print number of years
    printf("Years: %d\n", years);
}
